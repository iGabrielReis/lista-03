package br.edu.pinhais.fapi.Interfaces.Calculadora;

public interface Calcular {

	int calcularOperacaoSoma(int num1,int num2);
	int calcularOperacaoSubtracao(int num1,int num2);
	int calcularOperacaoMultiplicacao(int num1,int num2);
	int calcularOperacaoDivisao(int num1,int num2);
	
}
